package com.g88.mobilefps;

import net.fabricmc.api.ClientModInitializer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;

/**
 * First experimental build. Uses Minecraft's normal graphics settings only;
 * no Vulkan renderer and no mixins. Settings are applied after the client starts.
 */
public final class G88MobileFPS implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        // Schedule until the client has initialized its options and player/session.
        MinecraftClient client = MinecraftClient.getInstance();
        client.execute(() -> {
            try {
                client.options.getViewDistance().setValue(6);
                client.options.getSimulationDistance().setValue(4);
                client.options.getParticles().setValue(net.minecraft.client.option.ParticlesMode.MINIMAL);
                client.options.getEntityDistanceScaling().setValue(0.5);
                client.options.write();
                if (client.player != null) {
                    client.player.sendMessage(Text.literal("§b[G88 Mobile FPS] §fLow-end settings applied (6 chunks, minimal particles)."), false);
                }
            } catch (Throwable error) {
                System.err.println("[G88 Mobile FPS] Could not apply one or more settings: " + error);
            }
        });
    }
}
