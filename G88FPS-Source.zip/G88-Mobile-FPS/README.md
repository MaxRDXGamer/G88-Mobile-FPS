# G88 Mobile FPS — experimental source project

Target: Minecraft Java 1.21.11, Fabric Loader 0.19.2, Java 21. Intended for Android launchers such as Zalith Reborn. It does **not** use Vulkan and contains no mixins, so it avoids the previous `LowEndFPSBoost` mixin failure path.

## What this first build attempts
- View distance: 6 chunks
- Simulation distance: 4 chunks
- Particles: Minimal
- Entity distance scaling: 0.5
- Saves settings through Minecraft's normal options API

This is a conservative settings preset, not a new renderer. It may improve performance depending on the device/world but cannot guarantee a specific FPS increase. It may overlap with Sodium's own settings.

## Build
Use JDK 21 and internet access, then run:

```sh
./gradlew build
```

The project intentionally does not include a fabricated/precompiled JAR. The source must be compiled and tested against the exact 1.21.11 mappings before installation. If compilation reports a missing option method or enum, update the source to the actual Yarn API for the chosen mapping build.


## Cloud build (no Gradle install on Android)
A GitHub Actions workflow is included at `.github/workflows/build.yml`. Upload this source project to a GitHub repository, then use **Actions → Build G88 Mobile FPS → Run workflow**. If the build succeeds, download the `G88-Mobile-FPS-build` artifact from that workflow run. This still requires the project to compile successfully; the artifact must not be treated as device-tested until launched in Zalith Reborn.
